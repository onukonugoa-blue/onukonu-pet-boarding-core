import { useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { kennelsApi } from '../api/kennels'
import type { Kennel, KennelStaffOption } from '../api/kennels'
import { bookingsApi } from '../api/bookings'
import type { BookingStay } from '../api/bookings'
import { useBranchStore } from '../store/branch'

// ── Types ──────────────────────────────────────────────────────────────────

interface OccupiedInfo {
  stay_id: number
  booking_id: number
  pet_name: string
  pet_type: string
  client_name: string
  check_in_date: string
  check_out_date: string
  status: string
}

// ── Constants ──────────────────────────────────────────────────────────────

const STATUS_ORDER = ['Available', 'Occupied', 'Maintenance', 'Blocked'] as const

const STATUS_STYLES: Record<string, { section: string; dot: string; header: string }> = {
  Available:   { section: 'border-green-200 bg-green-50',   dot: 'bg-green-500',  header: 'text-green-700'  },
  Occupied:    { section: 'border-blue-200 bg-blue-50',     dot: 'bg-blue-500',   header: 'text-blue-700'   },
  Maintenance: { section: 'border-yellow-200 bg-yellow-50', dot: 'bg-yellow-500', header: 'text-yellow-700' },
  Blocked:     { section: 'border-red-200 bg-red-50',       dot: 'bg-red-500',    header: 'text-red-700'    },
}

// ── Helpers ─────────────────────────────────────────────────────────────────

function addDays(iso: string, n: number): string {
  const d = new Date(iso + 'T00:00:00')
  d.setDate(d.getDate() + n)
  return d.toISOString().slice(0, 10)
}

function canManageStaff(): boolean {
  const roles: string[] = (window as any).OPB?.user?.roles ?? []
  return roles.some((r) => ['opb_branch_manager', 'opb_super_admin', 'administrator'].includes(r))
}

// ── AssignPopover — from kennel card: choose a stay ────────────────────────

interface AssignPopoverProps {
  kennel: Kennel
  unassigned: BookingStay[]
  onAssign: (stayId: number, kennelId: number) => Promise<void>
  onClose: () => void
}

function AssignPopover({ kennel, unassigned, onAssign, onClose }: AssignPopoverProps) {
  const [selected, setSelected] = useState('')
  const [saving, setSaving]     = useState(false)
  const [error, setError]       = useState('')
  const ref = useRef<HTMLDivElement>(null)

  // Only show stays that belong to the same branch as this kennel.
  const eligible = unassigned.filter(
    (s) => s.branch_id == null || s.branch_id === kennel.branch_id
  )

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose()
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [onClose])

  const handleConfirm = async () => {
    if (!selected) return
    setSaving(true)
    setError('')
    try {
      await onAssign(Number(selected), kennel.id)
    } catch (e: any) {
      setError(e.message ?? 'Assignment failed')
    } finally {
      setSaving(false)
    }
  }

  return (
    <div
      ref={ref}
      className="absolute z-50 left-0 right-0 top-full mt-1 bg-white border border-green-300 rounded-lg shadow-lg p-3"
    >
      <p className="text-xs font-semibold text-gray-700 mb-2">Assign stay to {kennel.code}:</p>
      {error && <p className="text-xs text-red-600 mb-2 leading-snug">{error}</p>}
      {eligible.length === 0 ? (
        <p className="text-xs text-gray-400 italic">No unassigned stays for this branch.</p>
      ) : (
        <>
          <select
            className="form-input text-xs mb-2 w-full"
            value={selected}
            onChange={(e) => { setSelected(e.target.value); setError('') }}
            autoFocus
          >
            <option value="">— Select a stay —</option>
            {eligible.map((s) => (
              <option key={s.id} value={s.id}>
                {s.pet_name} · {s.client_name} · {s.check_in_date}
                {s.check_in_date !== s.check_out_date ? ` → ${s.check_out_date}` : ''} ({s.status})
              </option>
            ))}
          </select>
          <div className="flex gap-2">
            <button
              onClick={handleConfirm}
              disabled={!selected || saving}
              className="btn-primary text-xs py-1 px-3 flex-1"
            >
              {saving ? 'Assigning…' : 'Confirm'}
            </button>
            <button onClick={onClose} className="btn-secondary text-xs py-1 px-2">✕</button>
          </div>
        </>
      )}
    </div>
  )
}

// ── UnassignConfirm ────────────────────────────────────────────────────────

interface UnassignConfirmProps {
  onConfirm: () => void
  onCancel: () => void
  saving: boolean
}

function UnassignConfirm({ onConfirm, onCancel, saving }: UnassignConfirmProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const h = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onCancel()
    }
    document.addEventListener('mousedown', h)
    return () => document.removeEventListener('mousedown', h)
  }, [onCancel])

  return (
    <div
      ref={ref}
      className="absolute z-50 left-0 right-0 top-full mt-1 bg-white border border-red-300 rounded-lg shadow-lg p-3"
    >
      <p className="text-xs text-gray-700 mb-2">Remove this kennel assignment?</p>
      <div className="flex gap-2">
        <button
          onClick={onConfirm}
          disabled={saving}
          className="flex-1 text-xs font-medium bg-red-600 hover:bg-red-700 text-white rounded px-2 py-1 transition-colors"
        >
          {saving ? 'Removing…' : 'Yes, un-assign'}
        </button>
        <button onClick={onCancel} className="btn-secondary text-xs py-1 px-2">Cancel</button>
      </div>
    </div>
  )
}

// ── StaffSelector ──────────────────────────────────────────────────────────

interface StaffSelectorProps {
  kennel: Kennel
  staffOptions: KennelStaffOption[]
  onSave: (kennelId: number, wpUserId: number | null) => Promise<void>
}

function StaffSelector({ kennel, staffOptions, onSave }: StaffSelectorProps) {
  const [saving, setSaving] = useState(false)

  const handleChange = async (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value ? Number(e.target.value) : null
    setSaving(true)
    try { await onSave(kennel.id, val) }
    finally { setSaving(false) }
  }

  return (
    <div className="flex items-center gap-1 mt-1">
      <span className="text-gray-400 text-xs shrink-0">👤</span>
      <select
        className="text-xs text-gray-500 bg-transparent border-0 outline-none cursor-pointer w-full min-w-0 truncate disabled:opacity-60"
        value={kennel.assigned_staff_id != null ? String(kennel.assigned_staff_id) : ''}
        onChange={handleChange}
        disabled={saving}
        title="Assign staff member"
      >
        <option value="">Unassigned</option>
        {staffOptions.map((s) => (
          <option key={s.id} value={String(s.id)}>{s.name}</option>
        ))}
      </select>
    </div>
  )
}

// ── Main board ─────────────────────────────────────────────────────────────

export default function OccupancyBoard() {
  const [kennels, setKennels]           = useState<Kennel[]>([])
  const [occupancy, setOccupancy]       = useState<Record<number, OccupiedInfo>>({})
  const [unassigned, setUnassigned]     = useState<BookingStay[]>([])
  const [staffOptions, setStaffOptions] = useState<KennelStaffOption[]>([])
  const [loading, setLoading]           = useState(true)
  const [boardError, setBoardError]     = useState('')

  // Per-kennel card popovers
  const [assigningKennelId, setAssigningKennelId]     = useState<number | null>(null)
  const [unassigningKennelId, setUnassigningKennelId] = useState<number | null>(null)
  const [unassignSaving, setUnassignSaving]           = useState(false)
  const [flashId, setFlashId]                         = useState<number | null>(null)

  // Unassigned stays section: select+confirm (Issue 1 fix)
  const [selectedKennels, setSelectedKennels] = useState<Record<number, string>>({})
  const [assigningStayId, setAssigningStayId] = useState<number | null>(null)
  const [stayAssignErrors, setStayAssignErrors] = useState<Record<number, string>>({})

  const selectedBranch = useBranchStore((s) => s.activeBranchId) || null
  const today = new Date().toISOString().slice(0, 10)
  const isManager = canManageStaff()

  const load = async (branchId: number | null) => {
    setLoading(true)
    setBoardError('')
    try {
      // Issue 4: widen query to today+30 so upcoming unassigned stays appear
      const lookahead = addDays(today, 30)
      const calls: Promise<any>[] = [
        kennelsApi.list(branchId ?? undefined, true),
        bookingsApi.kennelBoard({
          from: today,
          to: lookahead,
          ...(branchId ? { branch_id: branchId } : {}),
        }),
      ]
      if (isManager) calls.push(kennelsApi.staffOptions())

      const [ks, board, opts] = await Promise.all(calls)
      setKennels(ks)
      if (opts) setStaffOptions(opts)

      const occ: Record<number, OccupiedInfo> = {}
      const unasgn: BookingStay[] = []

      ;(board.stays ?? []).forEach((s: BookingStay) => {
        if (s.status === 'Completed' || s.status === 'No show') return

        if (s.kennel_id) {
          // Issue 4: only mark kennel occupied TODAY if the stay overlaps today
          // Future pre-assigned stays should not show the kennel as occupied now
          if (s.check_in_date <= today && s.check_out_date >= today) {
            occ[Number(s.kennel_id)] = {
              stay_id: s.id, booking_id: s.booking_id,
              pet_name: s.pet_name ?? '', pet_type: s.pet_type ?? '',
              client_name: s.client_name ?? '',
              check_in_date: s.check_in_date, check_out_date: s.check_out_date,
              status: s.status,
            }
          }
        } else {
          // Unassigned: include Upcoming and Active stays without kennel
          unasgn.push(s)
        }
      })

      setOccupancy(occ)
      setUnassigned(unasgn)
      // Clear stale selections when data refreshes
      setSelectedKennels({})
      setStayAssignErrors({})
    } catch (e: any) {
      setBoardError(e.message ?? 'Failed to load board')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load(selectedBranch) }, [selectedBranch])

  const flash = (kennelId: number) => {
    setFlashId(kennelId)
    setTimeout(() => setFlashId(null), 1500)
  }

  // From kennel card → AssignPopover → this handler (errors bubble to popover)
  const handleAssignFromKennel = async (stayId: number, kennelId: number) => {
    await bookingsApi.assignKennel(stayId, kennelId) // may throw — popover catches
    setAssigningKennelId(null)
    flash(kennelId)
    load(selectedBranch)
  }

  const handleUnassign = async (kennelId: number, stayId: number) => {
    setUnassignSaving(true)
    try {
      await bookingsApi.assignKennel(stayId, null)
      setUnassigningKennelId(null)
      flash(kennelId)
      load(selectedBranch)
    } catch (e: any) {
      setBoardError(e.message ?? 'Un-assign failed')
      setUnassigningKennelId(null)
    } finally {
      setUnassignSaving(false)
    }
  }

  // Issue 1 fix: confirm button triggers this, not onChange
  const handleAssignFromStay = async (stayId: number) => {
    const kennelId = Number(selectedKennels[stayId])
    if (!kennelId) return
    setAssigningStayId(stayId)
    setStayAssignErrors((prev) => { const n = { ...prev }; delete n[stayId]; return n })
    try {
      await bookingsApi.assignKennel(stayId, kennelId)
      flash(kennelId)
      load(selectedBranch)
    } catch (e: any) {
      setStayAssignErrors((prev) => ({ ...prev, [stayId]: e.message ?? 'Assignment failed' }))
    } finally {
      setAssigningStayId(null)
    }
  }

  const handleStaffChange = async (kennelId: number, wpUserId: number | null) => {
    try {
      if (wpUserId) {
        await kennelsApi.assignStaff(kennelId, wpUserId)
      } else {
        await kennelsApi.removeStaff(kennelId)
      }
      load(selectedBranch)
    } catch (e: any) {
      setBoardError(e.message ?? 'Staff assignment failed')
    }
  }

  // All non-Maintenance/Blocked kennels — used for kennel card "Assign stay" button visibility.
  // Per-stay branch filtering happens inside AssignPopover and the unassigned stays dropdown.
  const assignableKennels = kennels.filter(
    (k) => k.status !== 'Maintenance' && k.status !== 'Blocked'
  )

  // Returns kennels eligible for a specific stay: same branch, not Maintenance/Blocked.
  const eligibleKennelsForStay = (stay: BookingStay) =>
    assignableKennels.filter(
      (k) => stay.branch_id == null || k.branch_id === stay.branch_id
    )

  const grouped = STATUS_ORDER.reduce<Record<string, Kennel[]>>((acc, s) => {
    acc[s] = kennels.filter((k) => {
      if (s === 'Occupied')  return occupancy[k.id] !== undefined
      if (s === 'Available') return k.status === 'Available' && !occupancy[k.id]
      return k.status === s
    })
    return acc
  }, {} as Record<string, Kennel[]>)

  if (loading) return <div className="flex items-center justify-center py-20 text-gray-400">Loading board…</div>

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Kennel Board</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Today — {new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
          </p>
        </div>
        <button onClick={() => load(selectedBranch)} className="btn-secondary text-sm">↻ Refresh</button>
      </div>

      {/* Tab nav */}
      <div className="flex gap-1 mb-5 border-b border-gray-200">
        <span className="px-4 py-2 text-sm font-medium text-blue-600 border-b-2 border-blue-600">
          Board
        </span>
        <Link
          to="/kennel/linear"
          className="px-4 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 border-b-2 border-transparent hover:border-gray-300 transition-colors"
        >
          Timeline
        </Link>
      </div>

      {boardError && (
        <div className="alert-error mb-4 flex items-start gap-2">
          <span>⚠️</span>
          <span>{boardError}</span>
          <button onClick={() => setBoardError('')} className="ml-auto text-red-400 hover:text-red-600 text-lg leading-none">×</button>
        </div>
      )}

      {/* Summary strip */}
      <div className="flex flex-wrap gap-3 mb-5">
        {STATUS_ORDER.map((s) => {
          const count = grouped[s].length
          if (count === 0) return null
          const st = STATUS_STYLES[s]
          return (
            <div key={s} className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-sm font-medium ${st.section}`}>
              <span className={`w-2 h-2 rounded-full ${st.dot}`} />
              <span className={st.header}>{s}</span>
              <span className="font-bold text-gray-800">{count}</span>
            </div>
          )
        })}
        {unassigned.length > 0 && (
          <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-orange-200 bg-orange-50 text-sm font-medium text-orange-700">
            <span className="w-2 h-2 rounded-full bg-orange-400" />
            Unassigned
            <span className="font-bold">{unassigned.length}</span>
          </div>
        )}
      </div>

      {kennels.length === 0 ? (
        <div className="empty-state">
          <span>🏠</span>
          <p>No kennels configured yet.</p>
          <p className="text-sm text-gray-400 mt-1">Go to Settings → Kennels to add kennel units.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {STATUS_ORDER.map((status) => {
            const items = grouped[status]
            if (items.length === 0) return null
            const st = STATUS_STYLES[status]
            const allowStaffAssign = isManager && status !== 'Maintenance' && status !== 'Blocked'

            return (
              <div key={status}>
                <h2 className={`text-xs font-semibold uppercase tracking-widest mb-3 flex items-center gap-2 ${st.header}`}>
                  <span className={`w-2 h-2 rounded-full ${st.dot}`} />
                  {status}
                  <span className="text-gray-400 font-normal normal-case tracking-normal">({items.length})</span>
                </h2>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
                  {items.map((k) => {
                    const occ           = occupancy[k.id]
                    const isFlashing    = flashId === k.id
                    const isAssigning   = assigningKennelId === k.id
                    const isUnassigning = unassigningKennelId === k.id

                    return (
                      <div
                        key={k.id}
                        className={`relative rounded-lg border-2 p-3 flex flex-col gap-1 transition-all duration-300
                          ${isFlashing ? 'border-green-400 bg-green-100 scale-105 shadow-md' : st.section}
                        `}
                      >
                        {/* Header */}
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-gray-900 text-sm">{k.code}</span>
                          {occ && (
                            <span className={`text-xs px-1.5 py-0.5 rounded-full border font-medium ${
                              occ.status === 'Active'
                                ? 'bg-green-100 text-green-800 border-green-200'
                                : 'bg-blue-100 text-blue-800 border-blue-200'
                            }`}>
                              {occ.status}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-gray-500 truncate">{k.name}</div>

                        {/* Staff */}
                        {allowStaffAssign && staffOptions.length > 0 ? (
                          <StaffSelector
                            kennel={k}
                            staffOptions={staffOptions}
                            onSave={handleStaffChange}
                          />
                        ) : k.assigned_staff_name ? (
                          <div className="text-xs text-gray-400 flex items-center gap-1">
                            <span>👤</span>
                            <span className="truncate">{k.assigned_staff_name}</span>
                          </div>
                        ) : null}

                        {/* Occupied: show pet info + un-assign */}
                        {occ && (
                          <>
                            <div className="mt-1 pt-1 border-t border-blue-200">
                              <Link
                                to={`/bookings/${occ.booking_id}`}
                                className="font-semibold text-sm text-blue-700 hover:underline block truncate"
                              >
                                {occ.pet_name}
                              </Link>
                              <div className="text-xs text-gray-500 truncate">{occ.client_name}</div>
                              <div className="text-xs text-gray-400 mt-0.5">
                                {occ.check_in_date} → {occ.check_out_date}
                              </div>
                            </div>
                            <button
                              onClick={() => setUnassigningKennelId(isUnassigning ? null : k.id)}
                              className="mt-1 w-full text-xs text-red-500 hover:text-red-700 hover:bg-red-50 rounded px-2 py-0.5 transition-colors border border-transparent hover:border-red-200 text-left"
                            >
                              {isUnassigning ? 'Cancel' : '✕ Un-assign'}
                            </button>
                          </>
                        )}

                        {/* Available: show assign button if there are unassigned stays */}
                        {status === 'Available' && !occ && (
                          <div className="mt-1">
                            {unassigned.length > 0 ? (
                              <button
                                onClick={() => setAssigningKennelId(isAssigning ? null : k.id)}
                                className="w-full text-xs font-medium text-green-700 hover:text-green-900 hover:bg-green-100 rounded px-2 py-1 transition-colors border border-green-200 bg-white"
                              >
                                {isAssigning ? 'Cancel' : '＋ Assign stay'}
                              </button>
                            ) : (
                              <span className="text-xs text-green-600 font-medium">Free</span>
                            )}
                          </div>
                        )}

                        {k.notes && (
                          <div className="text-xs text-gray-400 italic truncate mt-0.5" title={k.notes}>{k.notes}</div>
                        )}

                        {/* Assign stay popover */}
                        {isAssigning && (
                          <AssignPopover
                            kennel={k}
                            unassigned={unassigned}
                            onAssign={handleAssignFromKennel}
                            onClose={() => setAssigningKennelId(null)}
                          />
                        )}

                        {/* Un-assign confirm */}
                        {isUnassigning && occ && (
                          <UnassignConfirm
                            onConfirm={() => handleUnassign(k.id, occ.stay_id)}
                            onCancel={() => setUnassigningKennelId(null)}
                            saving={unassignSaving}
                          />
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* ── Unassigned Stays ── Issue 1 fix: select + confirm, no auto-fire */}
      {unassigned.length > 0 && (
        <div className="mt-6">
          <h2 className="text-xs font-semibold text-orange-600 uppercase tracking-widest mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-orange-400" />
            Unassigned Stays
            <span className="text-gray-400 font-normal normal-case tracking-normal">({unassigned.length})</span>
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {unassigned.map((s) => (
              <div key={s.id} className="rounded-lg border border-orange-200 bg-orange-50 p-3">
                <div className="flex items-center justify-between mb-1">
                  <Link to={`/bookings/${s.booking_id}`} className="font-semibold text-blue-700 hover:underline">
                    {s.pet_name}
                  </Link>
                  <span className={`text-xs px-1.5 py-0.5 rounded-full border font-medium ${
                    s.status === 'Active'
                      ? 'bg-green-100 text-green-800 border-green-200'
                      : 'bg-blue-100 text-blue-800 border-blue-200'
                  }`}>{s.status}</span>
                </div>
                <div className="text-xs text-gray-600">{s.client_name}</div>
                <div className="text-xs text-gray-400 mt-0.5 mb-2">{s.check_in_date} → {s.check_out_date}</div>

                {/* Branch-scoped kennel options for this stay */}
                {eligibleKennelsForStay(s).length > 0 ? (
                  <>
                    <div className="flex gap-2 items-center">
                      <select
                        className="form-input text-xs flex-1 py-1"
                        value={selectedKennels[s.id] ?? ''}
                        onChange={(e) => {
                          setSelectedKennels((prev) => ({ ...prev, [s.id]: e.target.value }))
                          setStayAssignErrors((prev) => { const n = { ...prev }; delete n[s.id]; return n })
                        }}
                      >
                        <option value="">Select kennel…</option>
                        {eligibleKennelsForStay(s).map((k) => (
                          <option key={k.id} value={k.id}>
                            {k.code} — {k.name}
                            {occupancy[k.id] ? ' (occupied today)' : ''}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => handleAssignFromStay(s.id)}
                        disabled={!selectedKennels[s.id] || assigningStayId === s.id}
                        className="btn-primary text-xs py-1 px-3 shrink-0"
                      >
                        {assigningStayId === s.id ? '…' : 'Assign'}
                      </button>
                    </div>
                    {stayAssignErrors[s.id] && (
                      <p className="text-xs text-red-600 mt-1 leading-snug">{stayAssignErrors[s.id]}</p>
                    )}
                  </>
                ) : (
                  <Link to={`/bookings/${s.booking_id}`} className="text-xs text-blue-600 hover:underline">
                    View booking →
                  </Link>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
